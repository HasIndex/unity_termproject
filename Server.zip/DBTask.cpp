#include "DBTask.h"

DBTask::DBTask() : type{}, session_id{}, is_success{}
{
}

DBTask::~DBTask()
{
}
